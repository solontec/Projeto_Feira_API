<script src="https://accounts.google.com/gsi/client" async defer></script>

<div id="g_id_onload"
    data-client_id="471307138333-njh18r1rajueo4auooa4mtutban1p6dt.apps.googleusercontent.com"
    data-auto_prompt="false"
    data-callback="handleCredentialResponse">
</div>

<button onclick="signOut()">Sign out</button>

<div class="g_id_signin" data-type="standard"></div>

<!-- Aqui ele vai te pedir para completar o cadastro conforme os dados requisitados  -->
<div id="modal" style="display:none; position:fixed; top:50%; left:50%; transform:translate(-50%, -50%); background:white; padding:20px; box-shadow: 0 0 10px rgba(0,0,0,0.3);">
    <h2>Complete seu cadastro</h2>

    <label>Digite sua data nascimento: <input type="date" id="questao"></label><br>
    <button onclick="salvarDados()">Salvar</button>
</div>

<script>
function handleCredentialResponse(response) {
    console.log("ID Token:", response.credential);

    const data = parseJwt(response.credential);
    const email = data.email;
    
    //Verifica se o usuario já foi cadastrado e se ele já foi vai mostrar a mensagem
    let userInfo = localStorage.getItem(email);
    if (userInfo ) {
        userInfo = JSON.parse(userInfo);
        if (userInfo.questao) {
            alert(`Bem-vindo, ${data.name}!`);
            return;
        }
    }

   
    document.getElementById("modal").style.display = "block";
    localStorage.setItem("currentUser", email);
}

function salvarDados() {
    const questao = document.getElementById("questao").value;
    const email = localStorage.getItem("currentUser");

 // Se não tiver idade inserida ele vai mostrar o modal para o usuario preecher por aqui
    if (!questao) {
        alert("Por favor, preencha todos os campos.");
        return;
    }

    // Aqui ele vai salvar os dados no localStorage que é a memoria do navegador para entrar, quando inserido as informações ele atualiza o cadastro e manda para o navegador
    localStorage.setItem(email, JSON.stringify({ questao }));
    document.getElementById("modal").style.display = "none";
    alert("Cadastro atualizado! Você pode continuar.");
}

    // Deslogar o login do google (propria API)
function signOut() {
    google.accounts.id.disableAutoSelect();
    alert("Você saiu da conta.");
}
// funcao pra decodificar e puxar os parametros do token, decodifica com o jWT e permite trazer parametros para o JS
function parseJwt(token) {
    const base64Url = token.split('.')[1];
    const base64 = base64Url.replace(/-/g, '+').replace(/_/g, '/');
    return JSON.parse(atob(base64));
}
</script>
